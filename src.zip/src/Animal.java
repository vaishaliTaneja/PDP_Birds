import java.util.Set;

public class Animal {

    private Boolean isExtinct;
    private Boolean isMammal;

    public Boolean getIsExtinct() {
        return isExtinct;
    }

    public void setIsExtinct(Boolean isExtinct) {
        this.isExtinct = isExtinct;
    }

    public Boolean getIsMammal() {
        return isMammal;
    }

    public void setIsMammal(Boolean isMammal) {
        this.isMammal = isMammal;
    }

    public Animal(Boolean isExtinct, Boolean isMammal) {
        this.isMammal = isMammal;
        this.isExtinct = isExtinct;
    }
}
