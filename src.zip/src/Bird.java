import java.util.Set;

public abstract class Bird extends Animal {
    private String typeOfBird;
    private String typeCharacteristic;
    private Boolean hasWings;
    private Set<String> preferredFoods;
    private static String generalCharacteristic = "warm-blooded, bipedal, vertebrate";

    public Bird(String typeOfBird, String typeCharacteristic, Boolean isExtinct, Boolean hasWings, Boolean isMammal, Set<String> preferredFoods) {
        super(isExtinct, isMammal);
        this.typeOfBird = typeOfBird;
        this.typeCharacteristic = typeCharacteristic;
        this.hasWings = hasWings;
        this.preferredFoods = preferredFoods;
    }

    public String getTypeOfBird() {
        return typeOfBird;
    }

    protected void setTypeOfBird(String typeOfBird) {
        this.typeOfBird = typeOfBird;
    }

    /**
     * set bird's characteristic
     */
    public void setCharacteristic(String typeCharacteristic) {
        this.typeCharacteristic = typeCharacteristic;
    }

    public String getCharacteristic() {
        return this.typeCharacteristic;
    }

    /**
     * get the number of wings of this bird
     */
    public Boolean getHasWings() {
        return hasWings;
    }

    /**
     * set the number of wings of this bird
     */
    public void setHasWings(Boolean hasWings) {
        this.hasWings = hasWings;
    }

    /**
     * get bird's favorite foods
     */
    public Set<String> getPreferredFoods() {
        return preferredFoods;
    }

    /**
     * set bird's favorite foods
     */
    public void setPreferredFoods(Set<String> preferredFoods) {
        this.preferredFoods = preferredFoods;
    }

    @Override
    public String toString() {
        return "Bird{" +
                ", type='" + typeOfBird + '\'' +
                ", default characteristic='" + generalCharacteristic + '\'' +
                ", species characteristic='" + typeCharacteristic + '\'' +
                ", extinct=" + this.getIsExtinct() +
                ", numOfWings=" + hasWings +
                ", favoriteFoods=" + preferredFoods +
                '}';
    }
}
